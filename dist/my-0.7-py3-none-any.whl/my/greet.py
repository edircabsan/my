def say_hello(name):
    print(F"Hello {name} from my v0.7")